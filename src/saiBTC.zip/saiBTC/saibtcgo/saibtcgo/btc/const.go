package btc

const(
	MessageMagic = "Bitcoin Signed Message:\n"
)
